<?php
	header("Location: checkout.php");
?>